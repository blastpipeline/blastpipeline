var filter = {
  url:
  [
    {hostContains: "example.com"},
    {hostPrefix: "developer"}
  ]
}

function logOnBefore(details) {
  console.info("onBeforeNavigate to: " + details.url);
}

browser.webNavigation.onBeforeNavigate.addListener(logOnBefore);
