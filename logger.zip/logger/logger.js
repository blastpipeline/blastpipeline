// match pattern for the URLs to redirect
//var pattern = "https://mdn.mozillademos.org/*";
var pattern = "https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/*";
var pattern2 = "https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Examples";

var sites_dict = {};

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// cancel function returns an object
// which contains a property `cancel` set to `true`
/*async function prefetch(requestDetails) {
  url = requestDetails.url;
  if (!(Object.keys(sites_dict).includes(url))) {
    return {cancel: false};
  }
  console.info("Triggered prefetch: " + url);
  for (var res of sites_dict[url]) {
    console.info("Prefetching:" + res);
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", res, true); // true for asynchronous request
    xmlHttp.send(null);
  }
  //await sleep(5000);
  return {cancel: false};
}*/

async function prefetchNav(requestDetails) {
  url = requestDetails.url;
  console.info("Started loading: " + url);
  if (!(Object.keys(sites_dict).includes(url))) {
    return {cancel: false};
  }
  console.info("Triggered prefetch: " + url);
  for (var res of sites_dict[url]) {
    console.info(res);
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", res, true); // true for asynchronous request
    //xmlHttp.setRequestHeader("cache-control", "public");
    xmlHttp.send();
  }
  return {cancel: false};
}

function log_request(requestDetails) {
  var d = new Date();
  var n = d.getMilliseconds();
  var s = d.getSeconds();
  console.log("Loading: " + s + "." + n + " " + requestDetails.url);
}

function log_completed(requestDetails) {
  var d = new Date();
  var n = d.getMilliseconds();
  var s = d.getSeconds();
  console.log("Completed: " + s + "." + n + " " + requestDetails.url);
}

function log_redirect(requestDetails) {
  var d = new Date();
  var n = d.getMilliseconds();
  var s = d.getSeconds();
  console.log("Redirect: " + s + "." + n + " " + requestDetails.originUrl + " " + requestDetails.redirectUrl);
}

const request = async () => {
	const response = await fetch("prefetch-res-addon-servers.txt");
	const data = await response.text();
	var li = data.split("\n");
	var site = "";
	var load_list = [];
	for (var i = 0; i < li.length; i++) {
		if (li[i].length != 0) {
			if (li[i][0] == "-") {
				load_list.push(li[i].slice(1));
			}
			else {
				if (load_list != [] && site != "") {
					sites_dict[site] = load_list;
					load_list = [];
				}
				site = li[i];
			}
		}
	}
	if (load_list != [] && site != "") {
		sites_dict[site] = load_list;
		load_list = [];
	}
	console.info(sites_dict);
	console.info(Object.keys(sites_dict));
	/*browser.webRequest.onBeforeRequest.addListener(
           prefetchNav,
	   {urls: ["<all_urls>"]},
	   ["blocking"]
	);*/

	browser.webNavigation.onBeforeNavigate.addListener(
           prefetchNav
	);
	
}
request();
/*var data = fetch("test.txt")
  .then(response => response.text())
  .then(text => console.info(text));*/
/*
var rawFile = new XMLHttpRequest();
rawFile.open("GET", "file://test.txt", false);
console.info("here");
console.info(rawFile.status);
console.info(rawFile.readyState);
rawFile.error = function() {
	console.info("error!!");
}
rawFile.onreadystatechange = function() 
{
	console.info("here2");
	if(rawFile.readyState == 4)
	{
		if (rawFile.status == 200 || rawFile.status == 0)
		{
			var mytext = rawFile.responseText; 
			console.log(mytext);
		}
	}
	rawFile.send(null);
}*/

// add the listener,
// passing the filter argument and "blocking"
/*browser.webRequest.onBeforeRequest.addListener(
  prefetch,
  //{urls: [pattern], types: ["image"]},
  {urls: [pattern, pattern2]},
  ["blocking"]
);*/
browser.webRequest.onCompleted.addListener(
  log_completed,
  {urls: ["<all_urls>"]}
);

browser.webRequest.onBeforeRequest.addListener(
  log_request,
  {urls: ["<all_urls>"]}
);

browser.webRequest.onBeforeRedirect.addListener(
  log_redirect,
  {urls: ["<all_urls>"]}
);


